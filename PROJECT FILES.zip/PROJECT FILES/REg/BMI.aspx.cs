﻿using System;
using System.Collections.Generic;
using BLL;
using DEL;
using DAL;

public partial class BMI : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            txtProfileid.Text = Session["patient"].ToString();

            BmiBLL bb = new BmiBLL();
            BmiCalc bc = bb.GetBmiValue(Session["patient"].ToString());


            if (bc != null)
            {
                txtbmi1.Text = bc.Bmi.ToString();
                TxtHeight1.Text = bc.Height.ToString();
                txtWeight1.Text = bc.Weight.ToString();
                txtBmiDate.Text = bc.BmiDate.ToString();
            }
            else
            {
                txtbmi1.Text = "0";
                TxtHeight1.Text = "0";
                txtWeight1.Text = "0";
                txtBmiDate.Text = "0";
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }

    }
    protected void Btn_Click(object sender, EventArgs e)
    {


        float height = float.Parse(txtHeight.Text);
        float weight = float.Parse(txtWeight.Text);
        float BMI = ((weight) / (height * height));
        Txtbmi.Text = BMI.ToString();
    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("PatientDetails.aspx");
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {


        if (Txtbmi.Text != "")
        {
            float a1 = float.Parse(Txtbmi.Text);
            float a2 = float.Parse(txtHeight.Text);
            float a3 = float.Parse(txtWeight.Text);

            if (((a3) / (a2 * a2)).ToString() == a1.ToString())
            {
                BmiBLL bb = new BmiBLL();
                BmiCalc b = new BmiCalc();

                b.Bmi = float.Parse(Txtbmi.Text);
                b.ProfileID = txtProfileid.Text;
                b.Height = float.Parse(txtHeight.Text);
                b.Weight = float.Parse(txtWeight.Text);
                b.BmiDate = DateTime.Now.ToString();

                if (bb.GetBmiValue(b.ProfileID) != null)
                {
                    if (bb.UpdateBmi(b))
                    {
                        BmiCalc bbb = bb.GetBmiValue(b.ProfileID);
                        Session["bmi"] = bbb.Bmi;
                        Response.Write("<script language='javascript'>window.alert('Your BMI has been calculated and saved in the DB successfully');window.location='PatientDetails.aspx';</script>");

                        // Response.Redirect("PatientDetails.aspx");
                    }
                    else
                    {
                        Response.Write("<script language='javascript'>window.alert('Error in calculating BMI. Please try again, later');window.location='BMI.aspx';</script>");

                        // Response.Redirect("BMI.aspx");
                    }
                }
                else
                {

                    if (bb.SaveBmi(b))
                    {
                        BmiCalc bbb = bb.GetBmiValue(b.ProfileID);
                        Session["bmi"] = bbb.Bmi;
                        Response.Write("<script language='javascript'>window.alert('Your BMI has been calculated and saved in the DB successfully');window.location='PatientDetails.aspx';</script>");
                        //Response.Redirect("PatientDetails.aspx");
                    }
                    else
                    {
                        Response.Write("<script language='javascript'>window.alert('Error in calculating BMI. Please try again, later');window.location='BMI.aspx';</script>");
                        // Response.Redirect("BMI.aspx");

                    }
                }
            }
            else
            {
                Response.Redirect("BMI.aspx");
            }

        }
        else
        {

            Response.Write("<script language='javascript'>window.alert('Please Calculate BMI    ');window.location='BMI.aspx';</script>");
   
           // Response.Redirect("BMI.aspx");
        }




    }
}