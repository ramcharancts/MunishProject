﻿using System;
using System.Collections.Generic;
using DEL;
using BLL;

public partial class RiskCalculation : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            txtProfileid.Text = Session["patient"].ToString();

            BmiBLL bb = new BmiBLL();
            BmiCalc bbb = bb.GetBmiValue(Session["patient"].ToString());
            if (bbb != null)
            {
                Session["bmi"] = bbb.Bmi;
                txtBMI.Text = Session["bmi"].ToString();

            }
            else
            {



            }


            RiskCalcBLL rr = new RiskCalcBLL();
            RiskCalc rc = rr.GetRiskCalcValue(Session["patient"].ToString());

            if (rc != null)
            {
                TxtBMI1.Text = rc.BMI.ToString();
                txtdiastolicvalue1.Text = rc.BP_Diastolic.ToString();
                txtsystolicvalue1.Text = rc.BP_Systolic.ToString();
                txtfastingglucosereading1.Text = rc.Glucose_Reading.ToString();
                txthdlcholestrolreading1.Text = rc.Cholesterol_Reading.ToString();
                txtserumtriglycerides1.Text = rc.Serum_Triglycerides.ToString();
                txtRiskDate.Text = rc.RiskDate.ToString();
                txtriskofdiabetis1.Text = rc.Risk.ToString();
            }
            else
            {
                TxtBMI1.Text = "0";
                txtdiastolicvalue1.Text = "0";
                txtsystolicvalue1.Text = "0";
                txtfastingglucosereading1.Text = "0";
                txthdlcholestrolreading1.Text = "0";
                txtserumtriglycerides1.Text = "0";
                txtRiskDate.Text = "0";
                txtriskofdiabetis1.Text = "0";
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }

    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        
    }
    protected void btncheck_Click(object sender, EventArgs e)
    {
        float bmi =float.Parse(txtBMI.Text);
        int systole = int.Parse(TxtBPSystolicValue.Text);
        int diastole = int.Parse(TxtBPDiastolicValue.Text);
        int glucose = int.Parse(TxtFastingGlucoseReading.Text);
        float Cholesterol = float.Parse(TxtHDLCholesterolReading.Text);
        float Serum = float.Parse(TxtBoxSerumTriglycerides.Text);
        string risk=string.Empty;
        int points = 0;
        if (bmi < 25)
        {
            points = 0;
        }
        else if (bmi >= 25 && bmi <= 29.9)
        {
            points = points + 2;
        }
        else if(bmi >=30)
        {
            points = points + 5;
        }

        if (systole >= 130 && diastole >= 85)
        {
            points = points + 2;
        }
        else
        {
            points = points + 0;
        }
     


        if (glucose < 100)
        {
            points = points + 0;
        }
        else if (glucose >= 100 && glucose < 126)
        {
            points = points + 10;
        }
        else if (glucose >= 126)
        {
            points = points + 20;
        }

        if (Cholesterol <40)
        {
            points = points + 5;
        }
        else if (Cholesterol >= 40)
        {
            points = points + 0;
        }

        if (Serum < 150)
        {
            points = points + 0;
        }
        else if (Serum >= 150)
        {
            points = points + 3;
        }

        if (points >= 0 && points <= 10)
        {
            risk = "<=3%";
        }
        else if (points >= 11 && points <= 12)
        {
            risk = "4%";
        }
        else if (points == 13 )
        {
            risk = "5%";
        }
        else if (points == 14)
        {
            risk = "6%";
        }
        else if (points == 15)
        {
            risk = "7%";
        }
        else if (points == 16)
        {
            risk = "9%";
        }
        else if (points == 17)
        {
            risk = "11%";
        }
        else if (points == 18)
        {
            risk = "13%";
        }
        else if (points == 19)
        {
            risk = "15%";
        }
        else if (points >= 20 && points <= 22)
        {
            risk = "22%";
        }
        else if (points >= 23 )
        {
            risk = "Greater than 35%";
        }
       
        TxtBoxRiskofDiabetes.Text = risk;
    }



        protected void btnSave_Click(object sender, EventArgs e)
        {

            if (TxtBoxRiskofDiabetes.Text != "")
            {
                RiskCalcBLL bb = new RiskCalcBLL();
                RiskCalc rc = new RiskCalc();
                rc.ProfileID = txtProfileid.Text;
                rc.BMI = float.Parse(txtBMI.Text);
                rc.BP_Diastolic = int.Parse(TxtBPDiastolicValue.Text);
                rc.BP_Systolic = int.Parse(TxtBPSystolicValue.Text);
                rc.Glucose_Reading = int.Parse(TxtFastingGlucoseReading.Text);
                rc.Cholesterol_Reading = float.Parse(TxtHDLCholesterolReading.Text);
                rc.Serum_Triglycerides = float.Parse(TxtBoxSerumTriglycerides.Text);
                rc.Risk = TxtBoxRiskofDiabetes.Text;
                rc.RiskDate = DateTime.Now.ToString();



                if (bb.GetRiskCalcValue(rc.ProfileID) != null)
                {
                    if (bb.UpdateRiskCalc(rc))
                    {
                        RiskCalc bbb = bb.GetRiskCalcValue(rc.ProfileID);

                        Response.Write("<script language='javascript'>window.alert('Patient’s risk percent has been calculated and have been saved in the DB successfully');window.location='PatientDetails.aspx';</script>");

                        // Response.Redirect("PatientDetails.aspx");
                    }
                    else
                    {
                        Response.Write("<script language='javascript'>window.alert('Error in calculating Risk. Please try again, later');window.location='RiskCalculation.aspx';</script>");

                        // Response.Redirect("BMI.aspx");
                    }
                }
                else
                {

                    if (bb.SaveRiskCalc(rc))
                    {
                        RiskCalc bbb = bb.GetRiskCalcValue(rc.ProfileID);
                        //Session["bmi"] = bbb.Bmi;
                        Response.Write("<script language='javascript'>window.alert('Patient’s risk percent has been calculated and have been saved in the DB successfully');window.location='PatientDetails.aspx';</script>");
                        //Response.Redirect("PatientDetails.aspx");
                    }
                    else
                    {
                        Response.Write("<script language='javascript'>window.alert('Error in calculating Risk. Please try again, later');window.location='RiskCalculation.aspx';</script>");
                        // Response.Redirect("BMI.aspx");

                    }
                }


            }
            else
            {
                Response.Write("<script language='javascript'>window.alert('Please calculate Risk');window.location='RiskCalculation.aspx';</script>");
                //Response.Redirect("RiskCalculation.aspx");
                //lRiskCheck.Text = "Please calculate Risk";
            }






        }
}