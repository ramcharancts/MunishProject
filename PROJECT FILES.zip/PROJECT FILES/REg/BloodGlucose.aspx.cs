﻿using System;
using System.Collections.Generic;
using DEL;
using BLL;

public partial class BloodGlucose : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["userid"] != null)
        {
            txtProfileid.Text = Session["patient"].ToString();
            BloodGlucoseBLL bg = new BloodGlucoseBLL();
            DEL.BloodGlucose bb = bg.GetBloodGlucoseValue(Session["patient"].ToString());

            if (bb != null)
            {
                Txtnotes1.Text = bb.Notes.ToString();
                txtbloodglucose.Text = bb.Glucose_Level.ToString();
                txttimeofday.Text = bb.TOD.ToString();
                txtglucoseDate.Text = bb.DateGlucose.ToString();
            }
            else
            {
                Txtnotes1.Text = "0";
                txtbloodglucose.Text = "0";
                txttimeofday.Text = "0";
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }


    }

    protected void BtnBack_Click(object sender, EventArgs e)
    {
      
     
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
       DEL.BloodGlucose bg = new DEL.BloodGlucose();

       BloodGlucoseBLL b = new BloodGlucoseBLL();

       bg.Notes = TxtNotes.Text;
       bg.Glucose_Level = int.Parse(txtBloodGlucoseLevel.Text);
       bg.ProfileID = txtProfileid.Text;
       if (DropDownListTimeofday.SelectedValue == "Morning")
       {
           bg.TOD = "Morning";
       }
       else if (DropDownListTimeofday.SelectedValue == "Evening")
       {
           bg.TOD = "Evening";
       }
       else
       {
            bg.TOD = "Afternoon";
       }
       bg.DateGlucose = DateTime.Now.ToString();
       if (b.GetBloodGlucoseValue(bg.ProfileID) != null)
       {
           if (b.UpdateBloodGlucose(bg))
           {
               Response.Write("<script language='javascript'>window.alert('Your readings have been saved in the DB successfully');window.location='PatientDetails.aspx';</script>");
             
             //  Response.Redirect("PatientDetails.aspx");
           }
           else
           {
               Response.Write("<script language='javascript'>window.alert(‘Error in saving readings. Please try again, later');window.location='BloodGlucose.aspx';</script>");
             
             //  Response.Redirect("BloodGlucose.aspx");
           }
       }
       else
       {

           if (b.SaveBloodGlucose(bg))
           {
               Response.Write("<script language='javascript'>window.alert('Your readings have been saved in the DB successfully');window.location='PatientDetails.aspx';</script>");
             
              // Response.Redirect("PatientDetails.aspx");
           }
           else
           {
               Response.Write("<script language='javascript'>window.alert(‘Error in saving readings. Please try again, later');window.location='BloodGlucose.aspx';</script>");
             
              // Response.Redirect("BloodGlucose.aspx");

           }
       }
     



      
    }
}