﻿using System;
using System.Collections.Generic;
using BLL;
using DAL;
using DEL;

public partial class PatientProfile : System.Web.UI.Page
{
   
    PatientBLL pa = new PatientBLL();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            RangeValidatorDob.MinimumValue = "01/01/1910";
            RangeValidatorDob.MaximumValue = DateTime.Now.ToString("MM/dd/yyyy");

            //if (Session["userid"] != null)
            //{
            //  count++;
            // count = count + 1;

            txtUserid.Text = Session["userid"].ToString();
        }
        //    }
        //    else
        //    {
        //        Response.Redirect("Home.aspx");
        //    }
        //}
        else
        {
            Response.Redirect("Login.aspx");
        }
    }
    
    
    protected void BtnRegister_Click(object sender, EventArgs e)
    {

        
        string name = (txtfirstname.Text).Substring(0,3);
        string year = (txtDob.Text).Substring(0, 4);
        
     //  int count=
        int count = pa.Get();
        string id = name+year + count.ToString("00");
       // count = Convert.ToInt32(count);



        Patient p = new Patient();
        PatientBLL pb = new PatientBLL();
        p.UserID = txtUserid.Text;
        p.ProfileID = id;
        p.First_Name = txtfirstname.Text;
        p.Last_Name = txtlastname.Text;
        p.Email = txtEmail.Text;
        if (RadioButton_Male.Checked)
        {
            p.Gender = "Male";
        }
        else
        {
            p.Gender = "Female";
        }

        p.DOB = txtDob.Text;
        p.Address = txtAddress.Text;
        p.State = txtState.Text;
        p.City = txtCity.Text;
        p.ZipCode = txtZipCode.Text;
        p.Guardian_First_Name = txtGuardian_First_Name.Text;
        p.Guardian_Last_Name = txtGuardian_last_Name.Text;
        p.Contact_No = txtContact_No.Text;
        p.Country = txtCountry.Text;

        if (pb.SavePatient(p))
        {
            Session["patient"] = id;
            Response.Write("<script language='javascript'>window.alert('Patient profile has been created successfully');window.location='PatientDetails.aspx';</script>");
           // Response.Redirect("PatientDetails.aspx");
        }
        else
        {
            Response.Write("<script language='javascript'>window.alert('Error in creating Patient profile. Please try again, later');window.location='PatientProfile.aspx';</script>");
           // Response.Redirect("PatientProfile.aspx");
        }
    }
}