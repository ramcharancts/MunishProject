﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using DEL;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {

    }
   
    protected void Button1_Click1(object sender, EventArgs e)
    {
        Patient p = new Patient();
        PatientBLL pb = new PatientBLL();
        p.UserID = txtUserid.Text;
        p.ProfileID = txtProfileid.Text;
        p.First_Name = txtfirstname.Text;
        p.Last_Name = txtlastname.Text;
        p.Email = txtEmail.Text;
        if (RadioButton_Male.Checked)
        {
            p.Gender = "Male";
        }
        else
        {
            p.Gender = "Female";
        }

        p.DOB = txtDob.Text;
        p.Address = txtAddress.Text;
        p.State = txtState.Text;
        p.City = txtCity.Text;
        p.ZipCode = txtZipCode.Text;
        p.Guardian_First_Name = txtGuardian_First_Name.Text;
        p.Guardian_Last_Name = txtGuardian_last_Name.Text;
        p.Contact_No = txtContact_No.Text;
        p.Country = txtCountry.Text;

        if (pb.SavePatient(p))
        {
            Label1.Text = "Success";
        }
        else
        {
            Label1.Text = "skjkd";
        }
    }
}