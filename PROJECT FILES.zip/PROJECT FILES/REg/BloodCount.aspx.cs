﻿using System;
using System.Collections.Generic;
using BLL;
using DEL;

public partial class BloodCount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            txtProfileid.Text = Session["patient"].ToString();

            BloodCountBLL bb = new BloodCountBLL();


            DEL.BloodCount bc = bb.GetBloodCountValue(Session["patient"].ToString());
            if (bc != null)
            {
                txtRBC1.Text = bc.RBC_Count.ToString();
                txtWBC1.Text = bc.WBC_Count.ToString();
                txtPlatelet1.Text = bc.Platelets.ToString();

            }
            else
            {
                txtRBC1.Text = "0";
                txtWBC1.Text = "0";
                txtPlatelet1.Text = "0";
            }
        }
        else
        {
            Response.Redirect("Login.aspx");
        }


    }
    protected void BtnCheck_Click(object sender, EventArgs e)
    {
        float WBC = float.Parse(txtWBCount.Text);
        float RBC = float.Parse(txtRBCCount.Text);
        int Platletes = int.Parse(TxtPlateletCount.Text);
        if (RBC <= 4.32 && RBC >= 5.72)
        {
           LRBC.Text= "Vitamin Deficiency";
        }
        else
        {
           LRBC.Text= "No Vitamin Deficiency";
        }

        if (WBC <= 3.5 && WBC >= 10.5)
        {
            LWBC.Text="prone to Cancer";
        }
        else
        {
            LWBC.Text="Not prone to Cancer";
        }

        if (Platletes <= 150 && Platletes >= 450)
        {
            LPlatelet.Text="Not immune to diseases";
        }
        else
        {
            LPlatelet.Text="immune to diseases";
        }
    }
    protected void BtnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("PatientProfile.aspx");
    }
    protected void BtnSave_Click(object sender, EventArgs e)
    {
        BloodCountBLL bb = new BloodCountBLL();
        DEL.BloodCount b = new DEL.BloodCount();
        b.ProfileID = txtProfileid.Text;
        b.RBC_Count = float.Parse(txtRBCCount.Text);
        b.WBC_Count = float.Parse(txtWBCount.Text);
        b.Platelets = int.Parse(TxtPlateletCount.Text);

        if (bb.GetBloodCountValue(b.ProfileID) != null)
        {
            if (bb.UpdateBloodCount(b))
            {
                Response.Write("<script language='javascript'>window.alert('Your Diagnosis has been done and the diagnosis information should be saved to the DB successfully');window.location='PatientDetails.aspx';</script>");

              //  Response.Redirect("PatientDetails.aspx");
            }
            else
            {
                Response.Write("<script language='javascript'>window.alert('Error in Diagnosis. Please try again, later');window.location='BloodCount.aspx';</script>");

               // Response.Redirect("BloodCount.aspx");
            }
        }
        else
        {

            if (bb.SaveBloodCount(b))
            {
                Response.Write("<script language='javascript'>window.alert('Your Diagnosis has been done and the diagnosis information should be saved to the DB successfully');window.location='PatientDetails.aspx';</script>");

               // Response.Redirect("PatientDetails.aspx");
            }
            else
            {
                Response.Write("<script language='javascript'>window.alert('Error in Diagnosis. Please try again, later');window.location='BloodCount.aspx';</script>");

              //  Response.Redirect("BloodCount.aspx");

            }
        }
     

    }
}