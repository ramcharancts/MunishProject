﻿using System;
using System.Collections.Generic;
using BLL;
using DAL;
using DEL;

public partial class Registrationex : System.Web.UI.Page
{
    //CountClassDEL cdel = new CountClassDEL();
    //int count = 2;
   
    protected void Page_Load(object sender, EventArgs e)
    {
        RangeValidator_Dob.MinimumValue = "01/01/1910";
        RangeValidator_Dob.MaximumValue = DateTime.Now.ToString("MM/dd/yyyy");
     Regbll R=new Regbll();
        //int count = cdel.count;
        string year = DateTime.Now.ToString("yyyy");
        string mon = DateTime.Now.ToString("MM");
       
        int count = R.Get() + 1;
       
        string id = year + mon + count.ToString("0000");
        
        
        txtUser_ID.Text = id;
    }

    protected void BtnRegister_Click(object sender, EventArgs e)
    {
        Registration r = new Registration();
        Regbll rb = new Regbll();
        r.UserID = txtUser_ID.Text;
        r.Password = txtPassword.Text;
        r.User_Name = txtUser_Name.Text;
        r.DOB = txtDob.Text;
        r.Age = Convert.ToInt32(txtAge.Text);

        if (RadioButtonMale.Checked)
        {
            r.Gender = "Male";
        }
        else
        {
            r.Gender = "Female";
        }

        r.Contact_No = txtContact_No.Text;
        r.Email = txtEmail.Text;
        r.Address = txtAddress.Text;
        r.State = txtState.Text;
        r.City = txtCity.Text;
        r.ZipCode = txtZipcode.Text;

     
        if (rb.SaveReg(r))
        {
            Response.Redirect("Login.aspx");
        }
        else
        {
            Response.Redirect("frmRegistration.aspx");
        }
        
    }



    protected void BtnReset_Click(object sender, EventArgs e)
    {
        Server.Transfer("frmRegistration.aspx");
    }
}