﻿using System;
using System.Collections.Generic;
using BLL;
using DEL;


public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BtnLogin_Click(object sender, EventArgs e)
    {

        Regbll r = new Regbll();
        PatientBLL p = new PatientBLL();
        
        string login = txtUserid.Text;
        string password = txtPassword.Text;


        

        if (r.GetById(login, password) != string.Empty)
        {
            Session["userid"] = txtUserid.Text;
            

            if(p.GetPatient(Session["userid"])!=null)
            {
                Patient pp = p.GetPatient(Session["userid"]);
                Session["patient"] = pp.ProfileID;
                Response.Write("<script language='javascript'>window.alert('sucesss');window.location='PatientDetails.aspx';</script>");
              //  Response.Redirect("PatientDetails.aspx");
            }
            else
            {
                Response.Write("<script language='javascript'>window.alert('sucesss');window.location='PatientProfile.aspx';</script>");
               // Response.Redirect("PatientProfile.aspx");
            }


        }
        else
        {
            Response.Write("<script language='javascript'>window.alert('Error in authorizing you. Please try again later');window.location='Login.aspx';</script>");
           // Response.Redirect("Login.aspx");
        }





     
        

    }
   
}