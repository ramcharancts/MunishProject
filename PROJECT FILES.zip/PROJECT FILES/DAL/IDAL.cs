﻿using System;
using System.Collections.Generic;


namespace DAL
{
    public interface IDAL <TEntity>
    {
        bool Save(TEntity entity);
        
    }
}
