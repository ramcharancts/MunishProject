﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using DEL;

namespace DAL
{
    public class BloodCountDAL:IDAL<BloodCount>
    {


        SqlConnection sql = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        bool IDAL<BloodCount>.Save(BloodCount bc)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "SaveBlood_Count @ProfileID='"+bc.ProfileID+"',@RBC_Count="+bc.RBC_Count+",@WBC_Count="+bc.WBC_Count+",@Platelets="+bc.Platelets+"";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }

        }

        public bool Update(BloodCount bc)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = " UpdateBlood_Count @ProfileID='" + bc.ProfileID + "',@RBC_Count=" + bc.RBC_Count + ",@WBC_Count=" + bc.WBC_Count + ",@Platelets=" + bc.Platelets + "";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }
        }


        public BloodCount GetBloodCount(Object obj)
        {
            BloodCount b = new BloodCount();
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = " GetBloodCount @ProfileID='" + obj + "'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    b.ProfileID = dr["ProfileID"].ToString();
                    b.Platelets = int.Parse(dr["Platelets"].ToString());
                    b.RBC_Count = float.Parse(dr["RBC_Count"].ToString());
                    b.WBC_Count = float.Parse(dr["WBC_Count"].ToString());
                    return b;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sql.Close();
            }
        }








    }
}
