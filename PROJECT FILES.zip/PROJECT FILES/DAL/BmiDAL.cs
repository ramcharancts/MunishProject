﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using DEL;
namespace DAL
{
    public class BmiDAL:IDAL<BmiCalc>
    {

        SqlConnection sql = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        bool IDAL<BmiCalc>.Save(BmiCalc b)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "SaveBMI @ProfileID='"+b.ProfileID+"',@Height="+b.Height+",@Weight="+b.Weight+",@BMI="+b.Bmi+",@BmiDate='"+b.BmiDate+"'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
              
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }

        }

        public bool Update(BmiCalc b)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "UpdateBMI @Height=" + b.Height + ",@Weight=" + b.Weight + ",@BMI=" + b.Bmi + ",@BmiDate='" + b.BmiDate + "',@ProfileID='" + b.ProfileID + "'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }
        }


        public BmiCalc GetBmi(Object obj)
        {
            BmiCalc b = new BmiCalc();
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "GetBmi @ProfileID='" + obj + "'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                dr = cmd.ExecuteReader();

                if (dr.HasRows == true)
                {
                    dr.Read();
                    b.ProfileID = dr["ProfileID"].ToString();
                    b.Height=float.Parse(dr["Height"].ToString());
                    b.Bmi= float.Parse(dr["BMI"].ToString());
                    b.Weight = float.Parse(dr["Weight"].ToString());
                    b.BmiDate = dr["BmiDate"].ToString();
                    return b;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sql.Close();
            }
        }


      
        



    }
}
