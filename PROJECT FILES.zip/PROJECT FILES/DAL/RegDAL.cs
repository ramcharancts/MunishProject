﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using DEL;
namespace DAL
{
    public class RegDAL : IDAL<Registration>
    {
        SqlConnection sql = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        bool IDAL<Registration>.Save(Registration p)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "SaveRegistration @UserID='" + p.UserID + "',@Password='" + p.Password + "',@User_Name='" + p.User_Name + "',@DOB='" + p.DOB + "',@Age=" + p.Age + ",@Gender='" + p.Gender + "',@Contact_No='" + p.Contact_No + "',@Email='" + p.Email + "',@Address='" + p.Address + "',@State='" + p.State + "',@City='" + p.City + "',@ZipCode='" + p.ZipCode+"'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }

        }



        public string Getbyid(Object obj1,Object obj2)
        {

            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "GetByIdRegistration @UserID='"+obj1+"',@Password='"+obj2+"'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                dr=cmd.ExecuteReader();
              
                    dr.Read();
                    return dr["UserID"].ToString();
                
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sql.Close();
            }
           
        }



        public int GetCount()
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "select count(*) as m from Registration";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                dr = cmd.ExecuteReader();
                dr.Read();
                int a = Convert.ToInt32(dr["m"].ToString());
                
           
                return a;

            }
            catch (Exception ex)
            {
                return 0;
            }
            finally
            {
                sql.Close();
            }

        }



    }
}
