﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using DEL;

namespace DAL
{
    public class RiskCalcDAL:IDAL<RiskCalc>
    {

        SqlConnection sql = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        bool IDAL<RiskCalc>.Save(RiskCalc bc)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "SaveRiskCalc @ProfileID='"+bc.ProfileID+"',@BMI="+bc.BMI+",@RiskDate='"+bc.RiskDate+"',@BP_Systolic="+bc.BP_Systolic+",@BP_Diastolic="+bc.BP_Diastolic+",@Glucose_Reading="+bc.Glucose_Reading+",@Cholesterol_Reading="+bc.Cholesterol_Reading+",@Serum_Triglycerides="+bc.Serum_Triglycerides+",@Risk='"+bc.Risk+"'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }

        }

        public bool Update(RiskCalc bc)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = " UpdateRiskCalc @ProfileID='" + bc.ProfileID + "',@BMI=" + bc.BMI + ",@RiskDate='" + bc.RiskDate + "',@BP_Systolic=" + bc.BP_Systolic + ",@BP_Diastolic=" + bc.BP_Diastolic + ",@Glucose_Reading=" + bc.Glucose_Reading + ",@Cholesterol_Reading=" + bc.Cholesterol_Reading + ",@Serum_Triglycerides=" + bc.Serum_Triglycerides + ",@Risk='" + bc.Risk + "'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }
        }




        public RiskCalc GetRiskCalc(Object obj)
        {
            RiskCalc b = new RiskCalc();
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = " GetRiskCalc @ProfileID='" + obj + "'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    b.ProfileID = dr["ProfileID"].ToString(); 
                    b.BP_Diastolic = int.Parse(dr["BP_Diastolic"].ToString());
                    b.BP_Systolic = int.Parse(dr["BP_Systolic"].ToString());
                    b.Glucose_Reading = int.Parse(dr["Glucose_Reading"].ToString());
                    b.Serum_Triglycerides = float.Parse(dr["Serum_Triglycerides"].ToString());
                    b.Cholesterol_Reading = float.Parse(dr["Cholesterol_Reading"].ToString());
                    b.BMI = float.Parse(dr["BMI"].ToString());
                    b.Risk = dr["Risk"].ToString();
                    b.RiskDate = dr["RiskDate"].ToString();

                    return b;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sql.Close();
            }
        }












    }
}
