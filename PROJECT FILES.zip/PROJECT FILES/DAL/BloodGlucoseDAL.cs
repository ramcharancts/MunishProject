﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using DEL;

namespace DAL
{
    public class BloodGlucoseDAL:IDAL<BloodGlucose>
    {


        SqlConnection sql = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        bool IDAL<BloodGlucose>.Save(BloodGlucose bc)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "SaveBloodGlucose @ProfileID='"+bc.ProfileID+"',@TOD='"+bc.TOD+"',@Glucose_Level="+bc.Glucose_Level+",@DateGlucose='"+bc.DateGlucose+"',@Notes='"+bc.Notes+"'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }

        }

        public bool Update(BloodGlucose bc)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = " UpdateBloodGlucose @ProfileID='" + bc.ProfileID + "',@TOD='" + bc.TOD + "',@Glucose_Level=" + bc.Glucose_Level + ",@DateGlucose='"+bc.DateGlucose+"',@Notes='" + bc.Notes + "'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }
        }

        public BloodGlucose GetBloodGluscose(Object obj)
        {
            BloodGlucose b = new BloodGlucose();
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = " GetBloodGlucose @ProfileID='"+obj+"'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    b.ProfileID = dr["ProfileID"].ToString();
                    b.TOD = dr["TOD"].ToString();
                    b.Glucose_Level = int.Parse(dr["Glucose_Level"].ToString());
                    b.Notes = dr["Notes"].ToString();
                    b.DateGlucose = dr["DateGlucose"].ToString();
                    return b;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sql.Close();
            }
        }

    }
}
