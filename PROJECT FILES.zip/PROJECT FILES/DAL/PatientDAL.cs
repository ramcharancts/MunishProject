﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using DEL;

namespace DAL
{
    public class PatientDAL:IDAL<Patient>
    {
        SqlConnection sql = new SqlConnection(DAL.Properties.Settings1.Default.conStr);
        SqlCommand cmd = new SqlCommand();
        SqlDataReader dr;

        bool IDAL<Patient>.Save(Patient p)
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "SavePatient @UserID= '"+p.UserID+"',@ProfileID='"+p.ProfileID+"',@First_Name='"+p.First_Name+"',@Last_Name='"+p.Last_Name+"',@Email='"+p.Email+"',@Gender='"+p.Gender+"',@DOB='"+p.DOB+"',@Address='"+p.Address+"',@State='"+p.State+"',@City='"+p.City+"',@ZipCode='"+p.ZipCode+"',@Guardian_First_Name='"+p.Guardian_First_Name+"',@Guardian_Last_Name='"+p.Guardian_Last_Name+"',@Contact_No='"+p.Contact_No+"',@Country='"+p.Country+"'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }

        }





        public bool Update(Patient p)
        {
           

            try
            {
                cmd.Connection = sql;
                cmd.CommandText = " UpdatePatient @UserID= '" + p.UserID + "',@First_Name='" + p.First_Name + "',@Last_Name='" + p.Last_Name + "',@Email='" + p.Email + "',@Gender='" + p.Gender + "',@DOB='" + p.DOB + "',@Address='" + p.Address + "',@State='" + p.State + "',@City='" + p.City + "',@ZipCode='" + p.ZipCode + "',@Guardian_First_Name='" + p.Guardian_First_Name + "',@Guardian_Last_Name='" + p.Guardian_Last_Name + "',@Contact_No='" + p.Contact_No + "',@Country='" + p.Country + "',@ProfileID='"+p.ProfileID+"'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                cmd.ExecuteNonQuery();

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                sql.Close();
            }
        }


        public Patient Check(Object obj)
        {
            Patient p = new Patient();
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = " GetByIdPatient @UserID= '" + obj+ "'";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                dr=cmd.ExecuteReader();

                if (dr.HasRows == true)
                {
                    dr.Read();
                        p.ProfileID = (dr["ProfileID"]).ToString();
                        p.UserID = (dr["UserID"]).ToString();
                        p.First_Name = (dr["First_Name"]).ToString();
                        p.Last_Name = (dr["Last_Name"]).ToString();
                        p.Email = (dr["Email"]).ToString();
                        p.Gender = (dr["Gender"]).ToString();
                        p.DOB = (dr["DOB"]).ToString();
                        p.Address = (dr["Address"]).ToString();
                        p.State = (dr["State"]).ToString();
                        p.City = (dr["City"]).ToString();
                        p.ZipCode = (dr["ZipCode"]).ToString();
                        p.Guardian_First_Name = (dr["Guardian_First_Name"]).ToString();
                        p.Guardian_Last_Name = (dr["Guardian_Last_Name"]).ToString();
                        p.Contact_No = (dr["Contact_No"]).ToString();
                        p.Country = (dr["Country"]).ToString();

                    
                    return p;
                }
                else
                {
                    return null;
                }
              
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                sql.Close();
            }
        }

        public int GetCountPatient()
        {
            try
            {
                cmd.Connection = sql;
                cmd.CommandText = "select count(*) as m from Patient_Profile";
                if (sql.State == System.Data.ConnectionState.Closed)
                {
                    sql.Open();
                }
                dr = cmd.ExecuteReader();
                dr.Read();
                int a = Convert.ToInt32(dr["m"].ToString());


                return a;

            }
            catch (Exception ex)
            {
                return 0;
            }
            finally
            {
                sql.Close();
            }

        }



    }
}
