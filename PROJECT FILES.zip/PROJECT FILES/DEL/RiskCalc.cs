﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DEL
{
    public class RiskCalc
    {
        public string ProfileID { get; set; }
        public float BMI { get; set; }
        public int BP_Systolic { get; set; }
        public int BP_Diastolic { get; set; }
        public int Glucose_Reading { get; set; }
        public float Cholesterol_Reading { get; set; }
        public float Serum_Triglycerides { get; set; }
        public string Risk { get; set; }
        public string RiskDate { get; set; }
    }
}
