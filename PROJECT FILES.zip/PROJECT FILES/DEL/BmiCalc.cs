﻿using System;
using System.Collections.Generic;


namespace DEL
{
    public class BmiCalc
    {
        public string ProfileID { get; set; }
        public float Height { get; set; }
        public float Weight { get; set; }
        public float Bmi { get; set; }
        public string BmiDate { get; set; }
       
    }
}
