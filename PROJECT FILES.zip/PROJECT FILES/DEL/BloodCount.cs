﻿using System;
using System.Collections.Generic;


namespace DEL
{
    public class BloodCount
    {
        public string ProfileID { get; set; }
        public double RBC_Count { get; set; }
        public double WBC_Count { get; set; }
        public int Platelets { get; set; }
    }
}
