﻿using System;
using System.Collections.Generic;


namespace DEL
{
    public class BloodGlucose
    {
        public string ProfileID { get; set; }
        public string TOD { get; set; }
        public int Glucose_Level { get; set; }
        public string Notes { get; set; }
        public string DateGlucose { get; set; }
    }
}
