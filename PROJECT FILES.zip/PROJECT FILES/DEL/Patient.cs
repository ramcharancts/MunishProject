﻿using System;
using System.Collections.Generic;


namespace DEL
{
    public class Patient
    {
        public string UserID { get; set; }
        public string ProfileID { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }
        public string DOB { get; set; }
        public string Address { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string Guardian_First_Name { get; set; }
        public string Guardian_Last_Name { get; set; }
        public string Contact_No { get; set; }
        public string Country { get; set; }
    }

}
