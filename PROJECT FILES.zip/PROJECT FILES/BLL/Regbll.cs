﻿using System;
using System.Collections.Generic;
using DAL;
using DEL;

namespace BLL
{
    public class Regbll
    {
        IDAL<Registration> i = new RegDAL();
       
        RegDAL rd = new RegDAL();

        public bool SaveReg(Registration p)
        {
            
           return i.Save(p);
        }

        public string GetById(Object obj1,Object obj2)
        {
            try
            {
               string str;
               str= rd.Getbyid(obj1, obj2).ToString();
               return str;
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }


        public int Get()
        {
               RegDAL r=new RegDAL();
               return r.GetCount();
        }
        
    }
}
