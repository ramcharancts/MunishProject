﻿using System;
using System.Collections.Generic;
using DAL;
using DEL;
namespace BLL
{
    public class BmiBLL
    {

        IDAL<BmiCalc> bmi = new BmiDAL();
        BmiDAL bb = new BmiDAL();

        public bool SaveBmi(BmiCalc b)
        {
            return bmi.Save(b);
        }

        public bool UpdateBmi(BmiCalc b)
        {
            return bb.Update(b);
        }
           public BmiCalc GetBmiValue(Object obj)
        {
            return bb.GetBmi(obj);
        }
    }
}
