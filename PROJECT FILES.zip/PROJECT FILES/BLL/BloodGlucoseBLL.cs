﻿using System;
using System.Collections.Generic;
using DEL;
using DAL;

namespace BLL
{
    public class BloodGlucoseBLL
    {
        IDAL<BloodGlucose> bg = new BloodGlucoseDAL();
        BloodGlucoseDAL bd = new BloodGlucoseDAL();
        
        public bool SaveBloodGlucose(BloodGlucose b)
        {
            return bg.Save(b);
        }

        public bool UpdateBloodGlucose(BloodGlucose b)
        {
            return bd.Update(b);
        }

        public BloodGlucose GetBloodGlucoseValue(Object obj){
            return bd.GetBloodGluscose(obj);
        }
    }
}
