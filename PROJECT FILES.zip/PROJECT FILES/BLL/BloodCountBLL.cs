﻿using System;
using System.Collections.Generic;
using DEL;
using DAL;

namespace BLL
{
    public class BloodCountBLL
    {
        IDAL<BloodCount> bc = new BloodCountDAL();
        BloodCountDAL bb=new BloodCountDAL();

        public bool SaveBloodCount(BloodCount b)
        {
            return bc.Save(b);
        }

        public bool UpdateBloodCount(BloodCount b1)
        {
            return bb.Update(b1);
        }

        public BloodCount GetBloodCountValue(Object obj)
        {
            return bb.GetBloodCount(obj);
        }
    }
}
