﻿using System;
using System.Collections.Generic;
using DAL;
using DEL;

namespace BLL
{
    public class RiskCalcBLL
    {

        IDAL<RiskCalc> rc = new RiskCalcDAL();
        RiskCalcDAL rr = new RiskCalcDAL();

        public bool SaveRiskCalc(RiskCalc r)
        {
            return rc.Save(r);
        }

        public bool UpdateRiskCalc(RiskCalc r)
        {
            return rr.Update(r);
        }


        public RiskCalc GetRiskCalcValue(Object obj)
        {
            return rr.GetRiskCalc(obj);
        }
    }
}
