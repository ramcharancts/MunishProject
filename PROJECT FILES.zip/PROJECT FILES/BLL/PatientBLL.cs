﻿using System;
using System.Collections.Generic;
using DEL;
using DAL;
namespace BLL
{
  public  class PatientBLL
    {
        IDAL<Patient> pd = new PatientDAL();

        PatientDAL pdd = new PatientDAL();
        public bool SavePatient(Patient p)
        {
            return pd.Save(p);
        }

        public bool UpdatePatient(Patient p)
        {
            return pdd.Update(p);
        }

        public Patient GetPatient(Object obj)
        {
            return pdd.Check(obj);
        }


        public int Get()
        {
            
            PatientDAL pd = new PatientDAL();
            
            return pd.GetCountPatient();
        }

    }
}
